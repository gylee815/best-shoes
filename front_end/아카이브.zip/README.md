# best-shoes
HTML + JavaScript
Front end for Best-shoes.com -> It can be hosted by AWS S3
The backgroud is consist of AWS Lambda
